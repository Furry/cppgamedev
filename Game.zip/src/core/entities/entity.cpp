#include "entity.h"
#include "../level/level.h"

#include <iostream>

// Entity::Entity() {}

// // void Entity::update(int tick, Level level) {};
// void Entity::render(sf::RenderWindow* window) {};
// void Entity::setPosition(sf::Vector2f position) {
//     this->position = position;
// };

// sf::Vector2f Entity::getPosition() {
//     return this->position;
// };