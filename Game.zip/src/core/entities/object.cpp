#include "object.h"

// TODO: all of this